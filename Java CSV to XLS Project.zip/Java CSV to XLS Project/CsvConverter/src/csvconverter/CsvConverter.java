
package csvconverter;
import java.io.FileOutputStream;
import java.io.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.*;
import au.com.bytecode.opencsv.CSVReader;
import java.io.FileReader;
import java.util.*;
import org.apache.poi.ss.usermodel.Row;
import java.util.Iterator;
import java.io.FileWriter;
import au.com.bytecode.opencsv.CSVWriter;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import org.apache.poi.ss.usermodel.Cell;
/**
 *
 * @author vdbergb
 */
public class CsvConverter {
    //File file = new File(getClass().getResource("/example.csv").toURI());
    /**
     * @param csvIn
     * @param exOut
     * @param args the command line arguments
     * @param sheet - sheet to sort
     * @param column - String column to sort by
     * @param rowStart - sorting from this row down
     */
    
    
    
    /*public static void sortSheet(HSSFSheet sheet, int column, int rowStart) throws ParseException {
        boolean sorting = true;
        int lastRow = sheet.getLastRowNum();
        while (sorting == true) {
        sorting = false;
        for (Row row : sheet) {
            // skip if this row is before first to sort
            if (row.getRowNum()<rowStart) continue;
            if (row.getRowNum()== lastRow) break;
            // end if this is last row
            Row nextRow= sheet.getRow(row.getRowNum()+1);
            
            if (nextRow== null)
                continue;
            
            
            
            //System.out.println(nextRow);
            //System.out.println("Firstvalue" + row.getCell(column));
              //Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1); 
            String one = row.getCell(column).getStringCellValue();
            String two = nextRow.getCell(column).getStringCellValue();
            //System.out.println(one);
            Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(one);
            Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(two);
            //DateTimeFormatter form = new DateTimeFormatter();
            Date firstValue =date1;
            Date secondValue = date2;
            System.out.println("Firstvalue" + firstValue);
            System.out.println("Secondvalue" + secondValue);
             //compare cell from current row and next row - and switch if secondValue should be before first
            if (secondValue.before(firstValue)) {                    
                sheet.shiftRows(nextRow.getRowNum(), nextRow.getRowNum(), -1);
                sheet.shiftRows(row.getRowNum(), row.getRowNum(), 1);
                sorting = true;
            }
        }
    }
    }*/   
    public static void csvToExcel(String csvIn, String exOut) throws URISyntaxException
    {
                //String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
                try{
                File f = new File(CsvConverter.class.getClass().getResource(csvIn).toURI());
                System.out.println(f + "\n");
                //File file = new File(CsvConverter.class.getResource(csvIn).toURI());
                //String inputCSVFile = "csv1.csv";
                CSVReader reader = new CSVReader(new FileReader(f));
                // Variables to loop through the CSV File 
                String [] nextLine; // String array for every line in the file            
                int lnNum = -50; //line number 
                //Define POI Spreadsheet objects         
                HSSFWorkbook new_workbook = new HSSFWorkbook(); //create a blank workbook object
                HSSFSheet sheet = new_workbook.createSheet("CSV2XLS");  //create a worksheet with caption score_details
                sheet.setColumnWidth(0, 5000);
                //Define logical Map to consume CSV file data into excel 
                Map<String, Object[]> excel_data = new HashMap<>(); //create a map and define data
                //Populate data into logical Map 
                while ((nextLine = reader.readNext()) != null) {
                        excel_data.put(Integer.toString(lnNum), new Object[] {nextLine[0],nextLine[1],nextLine[2],nextLine[3],nextLine[4]});
                        lnNum++;
                }
                // Create Excel Data from the map using POI 
                Set<String> keyset = excel_data.keySet();
                int rownum = 0;
                for (String key : keyset) { //loop through the data and add them to the cell
                        HSSFRow row = sheet.createRow(rownum++);
                        Object [] objArr = excel_data.get(key);
                        int cellnum = 0;
                        for (Object obj : objArr) {
                                HSSFCell cell = row.createCell(cellnum++);
                                
                                if(obj instanceof Double)
                                        cell.setCellValue((Double)obj);
                                else
                                        cell.setCellValue((String)obj);
                                }
                }
                /* Write XLS converted CSV file to the output file */
                FileOutputStream output_file = new FileOutputStream(new File(exOut)); //create XLS file
                new_workbook.write(output_file);//write converted XLS file to output stream
                output_file.close(); //close the file
         }catch(NullPointerException f)
         {
             System.out.println("Make sure that the input csv file is renamed to the current date." + f);
             System.exit(0);
         }catch(IOException e){
             System.out.println("IOException and URISyntax Exception has been thrown. Ensure that the file is in the correct directory and of correct format.\n" + e);
             System.exit(0);
         }
    }
  
    public static void excelToCsv(String exIn, String csvOut){
            try{
                //Scanner to catch input from user via keybord
                Scanner in = new Scanner(System.in);
                //First read the Excel file in binary format into FileInputStream
                FileInputStream input_document = new FileInputStream(new File(exIn));
                // Read workbook into HSSFWorkbook
                HSSFWorkbook my_xls_workbook = new HSSFWorkbook(input_document); 
                // Read worksheet into HSSFSheet
                HSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0); 
                // To iterate over the rows
                Iterator<Row> rowIterator = my_worksheet.iterator();
                // OpenCSV writer object to create CSV file
                FileWriter my_csv=new FileWriter(csvOut);
                CSVWriter my_csv_output=new CSVWriter(my_csv); 
                //Loop through rows.
                int colCount;
                System.out.println("How many columns? ");
                colCount = in.nextInt();
                
                while(rowIterator.hasNext()) {
                        Row row = rowIterator.next(); 
                        int i=0;
                        //String array
                        String[] csvdata = new String[colCount];
                        Iterator<Cell> cellIterator = row.cellIterator();
                                while(cellIterator.hasNext()) {
                                        Cell cell = cellIterator.next(); //Fetch the CELL 
                                        switch(cell.getCellType()) { //Identify the CELL type and then add it to the array
                                        case Cell.CELL_TYPE_STRING:
                                                csvdata[i]= cell.getStringCellValue();                                              
                                                break;
                                        }
                                        i=i+1;
                                }
                my_csv_output.writeNext(csvdata);
                }
                my_csv_output.close(); //close the CSV file
                //The file is created!!
                input_document.close(); //close xls file
            }catch(FileNotFoundException e){
                System.out.println("The desired file could not be found, ensure that it is in the designated folder! Restart Service when done.\n" + e);
                System.exit(0);
            }catch(IOException e){
                System.out.println("IOException has been thrown. Insure that file is of right format and structure. Restart Service when done.\n" + e);
                System.exit(0);
            }
        
    }
    
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        Properties prop = new Properties();
        //FileOutputStream out = new FileOutputStream("config.properties");
	InputStream input = null;
        String exOut = "";
        String csvOut = "";
        String csvIn = "";
        String exIn = "";
	try {
                
                input = new FileInputStream("config.properties");
		// load the properties file
		prop.load(input);
		// get the property value and print it out
		exOut = prop.getProperty("Exceloutput");
		csvOut = prop.getProperty("CSVoutput");
		csvIn = prop.getProperty("CSVinput");
                exIn = prop.getProperty("Excelinput");
                System.out.println(csvIn);
                
                
	} catch (IOException ex) {
		ex.printStackTrace();   
        }finally {
		if (input != null) {
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
        int answer = 0;
        Scanner in = new Scanner(System.in);
         try{
         while(answer != 3){
            System.out.println("Hello, Welcome to Converter" + "\nType 1 for CSV to Excel\n" + "Type 2 for Excel to CSV" + "\nType 3 to Exit!");
            answer= in.nextInt();
             switch (answer) {
                 case 1:
                     CsvConverter.csvToExcel(csvIn, exOut);
                     System.out.println("Convertion Done!!\n" + "Press 3 to exit.");
                     answer = in.nextInt();
                     break;
                 case 2:
                     CsvConverter.excelToCsv(exIn,csvOut);
                     System.out.println("Convertion Done!!\n" + "Press 3 to exit.");
                     answer = in.nextInt();
                     break;
                 case 3:
                     System.out.println("Goodbey!");
                     System.exit(0);
                     break;
                 default:
                     break;
             }
        }
         }catch(Exception e){
             System.out.println("Restart Service and choose a number from one of the selection options!\n");
             e.printStackTrace();
         }
    }
    
}
